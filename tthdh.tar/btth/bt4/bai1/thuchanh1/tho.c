troi hom nay that dep!
