#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/wait.h>
int main() {
    pid_t pid;
    int child_status, n;
    pid = fork();
    switch (pid) {
    case -1:
        printf("Khong tao duoc tien trinh con!\n");
        exit(1);
    case 0:
        n = 0;
        for (; n < 5; n++) {
            printf("Tien trinh con!\n");
            sleep(1);
        }
        exit(37);
    default:
        n = 3;
        for (; n > 0; n--) {
            printf("Tien trinh cha!\n");
            sleep(1);
        }
        wait(&child_status);
        printf("Tien trinh con hoan thanh: PID = %d\n", pid);
        if (WIFEXITED(child_status)) {
            printf("Tien trinh con thoat ra voi ma %d\n", WIFEXITED(child_status));
        }
        else {
            printf("Tien trinh con ket thuc binh thuong!\n");
        }
        break;
    }
    exit(0);
}