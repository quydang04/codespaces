#include <stdio.h>
#include <unistd.h>
int main() {
    printf("Thuc thi lenh ps voi execlp\n");
    execlp("ps", "ps", "-ax", NULL);
    printf("Thuc hien xong!");
    return 0;
}