#include <stdio.h>
#include <unistd.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <stdlib.h>
int main() {
    pid_t pid;
    int chid_status;
    int n;
    // Nhan ban tien trinh, tao ban sao moi
    pid = fork();
    switch (pid) {
        // Fork khong tao duoc tien trinh moi
    case -1:
        printf("Khong the tao tien trinh moi!\n");
        exit(1);
        // Fork thanh cong, dang o tien trinh con
    case 0:
        n = 0;
        for (; n < 5; n++)
        {
            printf("Tien trinh con!\n");
            sleep(1);
        }
        break;
        // Fork thanh cong, dang o tien trinh cha
    default:
        printf("Tien trinh cha, cho tien trinh con hoan thanh!\n");
        wait(&chid_status);
        printf("Tien trinh cha - tien trinh con hoan thanh!\n");
    }
    return 0;
}