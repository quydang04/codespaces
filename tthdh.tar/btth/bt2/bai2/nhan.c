int nhan(int a, int b) {
   return a*b;
}
