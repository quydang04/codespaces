#include <stdio.h>
void xuat(int a[100], int n) {
  printf("Mang ban vua nhap la: ");
  for(int i = 0; i < n; i++) {
   printf("%d ", a[i]);
}
  printf("\n");
}
