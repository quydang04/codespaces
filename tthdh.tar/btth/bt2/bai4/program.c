#include <stdio.h>
int main() {
 int a[100], n;
 printf("Nhap so luong phan tu: ");
 scanf("%d", &n);
 nhap(a, n);
 xuat(a, n);
 return 0;
}
