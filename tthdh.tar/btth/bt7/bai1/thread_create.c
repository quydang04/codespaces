#include <stdio.h>
#include <pthread.h>
void *do_loop(void *data) {
   int me = (int*) data;
   for(int i = 0; i < 5; i++) {
    sleep(1);
    printf(" '%d' - Got '%d' \n", me, i);
   }
   pthread_exit(NULL);
}
int main() {
    int thr_id, a = 1, b = 2;
    pthread_t p_thread;
    thr_id = pthread_create(&p_thread, NULL, do_loop, (void*)a);
    do_loop((void*)b);
    return 0;
}