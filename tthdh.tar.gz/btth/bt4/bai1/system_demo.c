#include <stdlib.h>
#include <stdio.h>

int main() {
    printf("\nThuc thi chuong trinh voi ham system\n");
    
    // Tạo thư mục thuchanh1
    system("mkdir thuchanh1 thuchanh2 && touch thuchanh1/tho.c");

    // Ghi nội dung vào file tho.c trong thuchanh1 và sao chép file tho.c từ thuchanh1 sang thuchanh2
    system("echo \"troi hom nay that dep!\" > thuchanh1/tho.c && cp thuchanh1/tho.c thuchanh2/");

    printf("Thuc hien xong!\n");
    return 0;
}