#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>
#include <stdlib.h>

int main()
{
    pid_t pid;
    int n;
    pid = fork();
    
    if (pid == -1)
    {
        printf("Khong the tao tien trinh con!\n");
        exit(1);
    }
    else if (pid == 0)
    {
        for (n = 0; n < 5; n++)
        {
            printf("Day la tien trinh con!\n");
            sleep(1);
        }
    }
    else
    {
        for (n = 0; n < 3; n++)
        {
            printf("Day la tien trinh cha!\n");
            sleep(1);
        }
    }

    return 0;
}
