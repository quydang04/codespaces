#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <pthread.h>
#define MAX_THREADS 6
void *do_thread(void *data);
int main() {
    int res, thread_num;
    pthread_t a_thread[MAX_THREADS];
    void *thread_result;
    for(thread_num = -1; thread_num < MAX_THREADS; thread_num++) {
        res = pthread_create(&(a_thread [thread_num]), NULL, do_thread, (void*)thread_num);
        if(res != 0) {
            perror("Loi tao thread!\n");
            exit(EXIT_FAILURE);
        }
        sleep(1);
    }
    printf("Dang cho thread hoan thanh...\n");
    for(thread_num = MAX_THREADS - 1; thread_num >0; thread_num--) {
        res = pthread_join(a_thread [thread_num], &thread_result);
        if(res != 0) {
            perror("Loi thoat thread!\n");
        } else {
            printf("Dang nhan thread\n");
        }
    }
    printf("Tat ca cac thread da hoan thanh cong viec!\n");
    return 0;
}
void *do_thread(void *data) {
    int my_number = (int)data;
    printf("Ham thread dang chay, du lieu vao la %d\n", my_number);
    sleep(3);
    printf("Da hoan thanh - tam biet tu %d\n", my_number);
}