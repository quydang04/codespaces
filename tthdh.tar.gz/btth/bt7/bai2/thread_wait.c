#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <pthread.h>
#include <string.h>
char message[] = "Hello world";
void *do_thread(void *data) {
   printf("Ham thread dang duoc thuc thi...\n");
   printf("Du lieu cua ham thread la %s\n", (char*)message);
   sleep(3);
   strcpy(message, "Bye!");
   pthread_exit("Cam on vi da su dung!");
}
int main() {
    int res;
    pthread_t a_thread;
    void *thread_result;
    res = pthread_create(&a_thread, NULL, do_thread, (void*)message);
    if(res != 0) {
        perror("Loi tao thread!\n");
        exit(EXIT_FAILURE);
    }
    printf("Dang doi thread hoan thanh!\n");
    res = pthread_join(a_thread, &thread_result);
    if(res != 0) {
        perror("Loi cho thread!\n");
        exit(EXIT_FAILURE);
    }
    printf("Thread da hoan thanh xong cong viec, bay gio thread tra ve ket qua la %s \n", (char*)thread_result);
    printf("Tin nhan bay gio la %s \n", message);
    return 0;
}