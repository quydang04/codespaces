#include <stdio.h>
#include <signal.h>
#include <unistd.h>
void catch_int(int sig_num) {
   signal(SIGTSTP, catch_int);
   printf("Don't press Ctrl+Z\n");
}
int main() {
    signal(SIGTSTP, catch_int);
    while(1) {
        printf("vodangphuquy - 2280602673\n");
        sleep(1);
    }
    return 0;
}